
<h1>Booking Successful</h1>
<p>{{ message }}</p>