<?php return [
    'plugin' => [
        'name' => 'Vehicles',
        'description' => ''
    ]
];