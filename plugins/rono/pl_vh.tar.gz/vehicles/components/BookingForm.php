<?php namespace Rono\Vehicles\Components;
use Cms\Classes\ComponentBase;
use Input;
use Config;
use Rono\Vehicles\Models\Bookings;
use Validator;
use ValidationException;
use Mail;
class BookingForm extends ComponentBase
{
    public function componentDetails()
    {
        return [
            'name' => 'Booking Form Component',
            'description' => 'Form booking standar'
        ];
    }
    public function defineProperties()
    {
        return [];
    }
    // after success formsubmit send notif to email
    public function onSendNotif()
    {
        $email = post('email');
        if (empty($email)) {
            return;
        }
        Mail::send('emails.notification', ['message' => 'Your booking has been confirmed.'], function($message) use ($email) {
            $message->to('wowosegainaru@gmail.com');
            $message->subject('Booking Success');
            $message->from($email, 'Booking Notification');
        });
    }
    public function onFormSubmit()
    {
        // Define validation rules
        $rules = [
            'nama' => 'required',
            'namaPerusahaan' => 'required',
            'email' => 'required|email',
            'domisiliKTP' => 'required',
            'namaGrup' => 'required',
            'idKaryawan' => 'required',
            'nomorTelepon' => 'required|numeric',
            'jenisMobil' => 'required',
            'testDrive' => 'required',
            'agreement' => 'accepted',
        ];
        // Custom messages (optional)
        $messages = [
            'required' => ':attribute wajib diisi.',
            'email' => 'Email tidak valid.',
            'numeric' => ':attribute harus berupa angka.',
            'accepted' => 'Anda harus menyetujui persyaratan sebelum mengirimkan.'
        ];
        $validation = Validator::make(post(), $rules, $messages);
        if ($validation->fails()) {
            throw new ValidationException($validation);
        }
        // Handle form submission (e.g., save data to the database, send an email, etc.)
         // Save the data to the database
        $booking = new Bookings();
        $booking->prospect_name = post('nama');
        $booking->prospect_company = post('namaPerusahaan');
        $booking->prospect_email = post('email');
        $booking->prospect_domisili = post('domisiliKTP');
        $booking->prospect_group = post('namaGrup');
        $booking->prospect_id_karyawan = post('idKaryawan');
        $booking->prospect_phone = post('nomorTelepon');
        $booking->vehicle_types_id = post('jenisMobil');
        $booking->test_drive = post('testDrive');
        $booking->tc_checked = post('agreement');
        $booking->save();
        $this->onSendNotif();
        Flash::success('Form submitted successfully!');
        return ['#result' => 'Form submitted successfully!'];
    }
    public function onRun(){
        // echo 'load templates';
    }
}
